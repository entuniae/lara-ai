# LärA-AI — Airy A0 editable poster

1. Upload this whole ZIP in Overleaf: New Project → Upload Project.
2. Select XeLaTeX as compiler.
3. Open `main.tex` and edit the clearly marked content commands: title, author, summary, background, methods, results, discussion, conclusion, takeaway, references and contact.
4. Replace graphics in `assets/` by uploading your own and updating the file paths in `main.tex`.
5. Change `\qrurl` to your actual destination (QR is functional, not a raster screenshot).
6. Edit the TikZ bar chart and colored waves directly in the source.

## Important note on logos
- `assets/lara_ai_logo.png` is cropped from the NEW tree logo supplied in the conversation (not the earlier draft tree).
- `assets/kth_seal.png` is from the original KTH PowerPoint provided earlier.
- `assets/uppsala_placeholder.png` and `assets/gavle_placeholder.png` are crops from a generated design preview. THEY ARE NOT VERIFIED OFFICIAL UNIVERSITY LOGOS. Replace with approved official assets before external publication. Avoid stretching or recoloring official logos.

Poster is A0 portrait, 841×1189 mm. The editable LaTeX is the source of truth; any PDF preview is just a compiled example.
